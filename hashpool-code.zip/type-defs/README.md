Diese .d.ts-Dateien stammen aus einer früheren Claude-Konversation (als Artefakte exportiert) und sind
TypeScript-Typdefinitionen aus Claudes eigener Umgebung (Artifact, MCP, Room, Files, User usw.) – nicht Teil
des Hashpool-Spiels selbst. Sie lagen als separate Dateien im Chatverlauf und werden hier nur mit ausgeliefert,
weil danach gefragt wurde.
