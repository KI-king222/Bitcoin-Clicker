# Hashpool – Bitcoin Miner Clicker

Alles ist eine einzige, in sich geschlossene HTML-Datei (HTML + CSS + JavaScript in einer Datei, nutzt three.js von cdnjs für die 3D-Ansicht). Es gibt keine separaten Modul-Dateien – der ganze Code lebt in dieser einen Datei.

## Dateien

- `index.html` – die aktuelle, vollständige Version des Spiels (Clicker, Upgrades, 3D-PC-Zusammenbau mit Tisch/Case/Kabeln, Markt, Hitze/Strom, Mining-Farm, Zufallsevents, Fehlersuche, Gebrauchtmarkt, Speedbau, Missionen, RGB-Look).
- `bitcoin-miner-before-extras.html` – Zwischenstand kurz vor den zusätzlichen Spielmechaniken (Markt/Hitze/Events/Farm/etc.), falls du die einfachere Version separat brauchst.

## Nutzung

Einfach `index.html` in einem Browser öffnen (Internetzugriff nötig für die three.js-Bibliothek von cdnjs.cloudflare.com). Speicherstand liegt in localStorage des Browsers.
